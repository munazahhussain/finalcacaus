enum Layout { grid, floating }
enum BuiltInButtons { callEnd, switchCamera, toggleCamera, toggleMic }
