
import 'package:flutter/material.dart';
import 'package:the_final_app_caucus/meeting_screen.dart';

import 'login.dart';
import 'join_meeting_screen.dart';
import 'main.dart';

class Joinmeeting2 extends StatefulWidget {
  Joinmeeting2({Key? key}) : super(key: key);

  @override
  _Joinmeeting2State createState() => _Joinmeeting2State();
}

class _Joinmeeting2State extends State<Joinmeeting2>
    with SingleTickerProviderStateMixin {
  bool isSwitchedAudio = false;
  bool isSwitchedVideo = false;

  get primary => null;
  @override
  void initState() {
    super.initState();
  }

  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return new Scaffold(
      resizeToAvoidBottomInset: false,
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        automaticallyImplyLeading: false,
        elevation: 0,
        title: Row(
          children: [
            GestureDetector(
                onTap: () {
                  Navigator.push(
                      context, MaterialPageRoute(builder: (_) => MyApp()));
                },
                child: Text(
                  "Cancel",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                  ),
                )),
            SizedBox(
              width: 45,
            ),
            Text(
              "Join a Meeting",
              style: TextStyle(color: Colors.white, fontSize: 18),
            ),
          ],
        ),
      ),
      body: Column(
        children: [
          SizedBox(
            height: 30,
          ),
          Container(
              height: 50,
              decoration: BoxDecoration(color: Colors.teal),
              child: Row(
                children: [
                  Container(
                    width: size.width * 0.1,
                    height: 40,
                  ),
                  Container(
                    width: size.width * 0.9,
                    child: Padding(
                      padding: const EdgeInsets.only(top: 3),
                      child: TextField(
                        textAlign: TextAlign.center,
                        cursorColor: primary,
                        keyboardType: TextInputType.number,
                        decoration: InputDecoration(
                          border: InputBorder.none,
                          hintText: "Meeting Id",
                          hintStyle: TextStyle(color: Colors.white),
                          suffixIcon: Icon(
                            Icons.keyboard_arrow_down,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              )),
          Container(
              height: 50,
              decoration: BoxDecoration(color: Colors.white),
              child: Row(
                children: [
                  Container(
                    width: size.width * 0.1,
                    height: 40,
                  ),
                  Container(
                    width: size.width * 0.9,
                    child: Padding(
                      padding: const EdgeInsets.only(top: 3),
                      child: TextField(
                        textAlign: TextAlign.center,
                        cursorColor: primary,
                        keyboardType: TextInputType.multiline,
                        decoration: InputDecoration(
                          border: InputBorder.none,
                          hintText: "Join with meeting Id",
                          hintStyle: TextStyle(color: Colors.teal),
                        ),
                        onTap: () {
                          // Navigator.push(
                          //     context,
                          //     MaterialPageRoute(
                          //         builder: (context) => JoinMeeting()));
                        },
                      ),
                    ),
                  ),
                ],
              )),
          Container(
              height: 50,
              decoration: BoxDecoration(color: Colors.teal),
              child: Row(
                children: [
                  Container(
                    width: size.width * 0.1,
                    height: 40,
                  ),
                  Container(
                    width: size.width * 0.9,
                    child: Padding(
                      padding: const EdgeInsets.only(top: 3),
                      child: TextField(
                        textAlign: TextAlign.center,
                        cursorColor: primary,
                        keyboardType: TextInputType.name,
                        decoration: InputDecoration(
                          border: InputBorder.none,
                          hintText: "Your Name",
                          hintStyle: TextStyle(color: Colors.white),
                        ),
                      ),
                    ),
                  ),
                ],
              )),
          Center(
            child: Container(
              padding: EdgeInsets.only(top: 30),

              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,

                children: <Widget>[
                  new MaterialButton(
                    color: Colors.teal,
                    textColor: Colors.white,
                    child: new Text("Join"),
                    onPressed: () {
                      // Navigator.push(context,
                      //     MaterialPageRoute(builder: (context) => MeetingScreen()));
                    },
                    splashColor: Colors.blueAccent,
                  ),
                ],
              ),
            ),
          ),
          Divider(
            height: 100,
            thickness: 0.2,
            color: Colors.white,
          ),
          Container(
            height: 50,
            decoration: BoxDecoration(color: Colors.teal),
            child: Padding(
              padding: const EdgeInsets.only(left: 20, right: 5),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "Turn Off My Video",
                    style: TextStyle(
                        color: Colors.white,
                        height: 1.3,
                        fontSize: 15,
                        fontWeight: FontWeight.w600),
                  ),
                  Switch.adaptive(
                    activeColor: primary,
                    value: isSwitchedVideo,
                    onChanged: (value) {
                      setState(() => {this.isSwitchedVideo});
                    },
                  ),
                ],
              ),
            ),
          ),
          Container(
            height: 60,
            decoration: BoxDecoration(color: Colors.teal),
            child: Padding(
              padding: const EdgeInsets.only(left: 20, right: 5),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "Don't Connect to Audio",
                    style: TextStyle(
                        color: Colors.white,
                        height: 1.3,
                        fontSize: 15,
                        fontWeight: FontWeight.w600),
                  ),
                  Switch.adaptive(
                    activeColor: primary,
                    value: isSwitchedVideo,
                    onChanged: (value) {
                      setState(() => {this.isSwitchedAudio});
                    },
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
