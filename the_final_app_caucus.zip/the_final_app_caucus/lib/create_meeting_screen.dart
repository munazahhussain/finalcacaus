import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_dynamic_links/firebase_dynamic_links.dart';
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:the_final_app_caucus/meeting_screen.dart';
import 'package:the_final_app_caucus/user.dart';
import 'package:the_final_app_caucus/utils.dart';

class CreateMeeting extends StatefulWidget {
  CreateMeeting({Key? key}) : super(key: key);

  @override
  _CreateMeetingState createState() => _CreateMeetingState();
}

class _CreateMeetingState extends State<CreateMeeting>
    with SingleTickerProviderStateMixin {
  TextEditingController nameController = new TextEditingController();
  TextEditingController sectionController = new TextEditingController();
  TextEditingController roomController = new TextEditingController();
  TextEditingController subjectController = new TextEditingController();
  TextEditingController passwordController = new TextEditingController();
  late AnimationController _iconAnimationController;
  late Animation<double> _iconAnimation;

  Future createMeeting(class_name, section, room, subject, meeting_pass) async {

    if(class_name.toString().isEmpty || section.toString().isEmpty ||room.toString().isEmpty || subject.toString().isEmpty ||meeting_pass.toString().isEmpty  ){
      Utils.showToast( 'All Fields Required');
      return;
    }
    FocusScope.of(context).requestFocus(FocusNode());
    await Permission.microphone.request();
    await Permission.camera.request();

    // final String api = "http://localhost:3000/user/register";
    // final response = await http.post(Uri.parse(api), body: {
    //   "class_name": class_name,
    //   "section": section,
    //   "room": room,
    //   "subject": subject,
    //   "meeting_pass": meeting_pass
    // });
    // print(response.body);
    isLoading = true;
    String email = "non";
    setState(() {});
    // try {
    //   email = FirebaseAuth.instance.currentUser!.email.toString();
    // } catch (e) {}
    String channel = "test";
    String token = Token;

    CollectionReference meetings =
        FirebaseFirestore.instance.collection('meetings');
    meetings.add({
      "class_name": class_name,
      "section": section,
      "room": room,
      "subject": subject,
      "pass": meeting_pass,
      'channel': channel,
      'token': token,
      //  'createdBy': email
    }).then((value) {
      String id = value.id;
      print(id);
      print("meeting Added to firebase");
      final DynamicLinkParameters parameters = DynamicLinkParameters(
        uriPrefix: 'https://caucusflutter.page.link/',
        link: Uri.parse('https://subdomainapp.example.com/product?id=$id'),
        androidParameters: AndroidParameters(
          packageName: 'com.example.the_final_app_caucus',
          minimumVersion: 1,
        ),
        iosParameters: IosParameters(
          bundleId: 'com.example.ios',
          minimumVersion: '1.0.1',
          appStoreId: '123456789',
        ),
        googleAnalyticsParameters: GoogleAnalyticsParameters(
          campaign: 'example-promo',
          medium: 'social',
          source: 'orkut',
        ),
        itunesConnectAnalyticsParameters: ItunesConnectAnalyticsParameters(
          providerToken: '123456',
          campaignToken: 'example-promo',
        ),
        socialMetaTagParameters: SocialMetaTagParameters(
          title: 'Caucus ',
          description: 'Meeting Application',
        ),
      );

      parameters.buildShortLink().then((value) {
        final Uri shortUrl = value.shortUrl;
        print(shortUrl);
        meetings.doc(id).update({
          'link': shortUrl.toString(),
        }).whenComplete(() {
          MeetingUser user = new MeetingUser(0, '$class_name Instructor');
          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => MeetingScreen(token, channel,
                      shortUrl.toString(), id, false, user))).then((value) {
            Navigator.pop(context);
            //isLoading=false;
            // setState(() {
            //
            // });
          });
        });
      });
    }).catchError((error) {
      isLoading = false;
      setState(() {});
      print("Failed to add meeting: $error");
      Utils.showToast("Failed to add meeting: $error");
    });
  }

  @override
  void initState() {
    super.initState();
    _iconAnimationController = new AnimationController(
        vsync: this, duration: new Duration(milliseconds: 500));
    _iconAnimation = new CurvedAnimation(
        parent: _iconAnimationController, curve: Curves.easeOut);
    _iconAnimation.addListener(() => this.setState(() {}));
    _iconAnimationController.forward();
  }

  bool isLoading = false;

  Widget build(BuildContext context) {
    return new Scaffold(
      backgroundColor: Colors.black,
      body: new Stack(
        fit: StackFit.expand,
        children: <Widget>[
          new Image(
            image: new AssetImage("assets/pic2.jpg"),
            fit: BoxFit.cover,
            color: Colors.black54,
            colorBlendMode: BlendMode.darken,
          ),
          isLoading
              ? Center(
                  child: Text(
                  'Creating Meeting...',
                  style: TextStyle(fontSize: 20.0, color: Colors.red),
                ))
              : new Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    new FlutterLogo(
                      size: _iconAnimation.value * 50,
                    ),
                    new Form(
                      child: new Theme(
                        data: new ThemeData(
                            brightness: Brightness.dark,
                            primarySwatch: Colors.teal,
                            inputDecorationTheme: new InputDecorationTheme(
                                labelStyle: new TextStyle(
                                    color: Colors.teal, fontSize: 20.0))),
                        child: new Container(
                          padding: const EdgeInsets.all(22.0),
                          alignment: Alignment.center,
                          child: new Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: <Widget>[
                              new TextFormField(
                                controller: nameController,
                                decoration: new InputDecoration(
                                  labelText: "Class Name(required)",
                                ),
                                keyboardType: TextInputType.text,
                              ),
                              new TextFormField(
                                controller: sectionController,
                                decoration: new InputDecoration(
                                  labelText: "Section",
                                ),
                                keyboardType: TextInputType.text,
                                obscureText: false,
                              ),
                              new TextFormField(
                                controller: roomController,
                                decoration: new InputDecoration(
                                  labelText: "Room",
                                ),
                                keyboardType: TextInputType.text,
                              ),
                              new TextFormField(
                                controller: subjectController,
                                decoration: new InputDecoration(
                                  labelText: "Subject",
                                ),
                                keyboardType: TextInputType.text,
                              ),
                              new TextFormField(
                                decoration: new InputDecoration(
                                  labelText: "Meeting Password",
                                ),
                                keyboardType: TextInputType.text,
                                controller: passwordController,
                                validator: (value) {
                                  if (value!.isEmpty || value.length <= 5) {
                                    return 'invalid password';
                                  }
                                  return null;
                                },
                              ),
                              new Padding(
                                padding: const EdgeInsets.only(top: 20.0),
                              ),
                              new MaterialButton(
                                color: Colors.teal,
                                textColor: Colors.white,
                                child: new Text("Done"),
                                onPressed: () => {
                                  print(nameController.text),
                                  createMeeting(
                                      nameController.text,
                                      sectionController.text,
                                      roomController.text,
                                      subjectController.text,
                                      passwordController.text),
                                },
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
        ],
      ),
    );
  }
}
