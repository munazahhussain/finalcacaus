import 'dart:math';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:the_final_app_caucus/dashboard.dart';
import 'package:the_final_app_caucus/utils.dart';

import 'login.dart';

class SignUp extends StatefulWidget {
  static const routeName = '/signUp';

  SignUp({Key? key}) : super(key: key);

  @override
  _SignUpState createState() => _SignUpState();
}

class _SignUpState extends State<SignUp> with SingleTickerProviderStateMixin {
  TextEditingController passwordController = new TextEditingController();
  TextEditingController nameController = new TextEditingController();
  TextEditingController emailController = new TextEditingController();
  TextEditingController confirm = new TextEditingController();
  late AnimationController _iconAnimationController;
  late Animation<double> _iconAnimation;

  Future createUser(String name, String email, String password) async {
    // final String api = "http://localhost:3000/user/register";
    // final response = await http.post(Uri.parse(api),
    //     body: {"name": name, "email": email, "password": password});
    // print(response.body);
    FocusScope.of(context).requestFocus(FocusNode());

    try {
      UserCredential userCredential = await FirebaseAuth.instance
          .createUserWithEmailAndPassword(email: email, password: password);

      FocusScope.of(context).requestFocus(FocusNode());
      CollectionReference meetings =
          FirebaseFirestore.instance.collection('users');
      var rng = new Random();
      var id = rng.nextInt(1000);
      meetings.add({"name": name, "email": email, "id": id}).then((value) {
        Utils.showToast("User Registered");
        print("meeting Added");
        return Navigator.push(
            context, MaterialPageRoute(builder: (context) => Dashboard()));
      }).catchError((error) => print("Failed to add user: $error"));
    } on FirebaseAuthException catch (e) {
      if (e.code == 'weak-password') {
        Utils.showToast('The password provided is too weak.');
        print('The password provided is too weak.');
      } else if (e.code == 'email-already-in-use') {
        Utils.showToast('The account already exists for that email.');
        print('The account already exists for that email.');
      }
    } catch (e) {
      print(e);
    }
  }

  @override
  void initState() {
    super.initState();

    _iconAnimationController = new AnimationController(
        vsync: this, duration: new Duration(milliseconds: 500));
    _iconAnimation = new CurvedAnimation(
        parent: _iconAnimationController, curve: Curves.easeOut);
    _iconAnimation.addListener(() => this.setState(() {}));
    _iconAnimationController.forward();
  }

  Widget build(BuildContext context) {
    return new Scaffold(
        backgroundColor: Colors.black,
        body: new Stack(fit: StackFit.expand, children: <Widget>[
          new Image(
            image: new AssetImage("assets/pic2.jpg"),
            fit: BoxFit.cover,
            color: Colors.black54,
            colorBlendMode: BlendMode.darken,
          ),
          new Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                new FlutterLogo(
                  size: _iconAnimation.value * 100,
                ),
                new Form(
                    child: new Theme(
                        data: new ThemeData(
                            brightness: Brightness.dark,
                            primarySwatch: Colors.teal,
                            inputDecorationTheme: new InputDecorationTheme(
                                labelStyle: new TextStyle(
                                    color: Colors.teal, fontSize: 20.0))),
                        child: new Container(
                          padding: const EdgeInsets.all(40.0),
                          child: new Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: <Widget>[
                                new TextFormField(
                                  controller: nameController,
                                  decoration: new InputDecoration(
                                    labelText: "Enter Name",
                                  ),
                                  keyboardType: TextInputType.text,
                                ),
                                new TextFormField(
                                  controller: emailController,
                                  decoration: new InputDecoration(
                                    labelText: "Enter email",
                                  ),
                                  keyboardType: TextInputType.text,
                                  validator: (value) {
                                    if (value!.isEmpty || value.contains('@')) {
                                      return 'invalid email';
                                    }
                                    return null;
                                  },
                                ),
                                new TextFormField(
                                  decoration: new InputDecoration(
                                      labelText: "Password", hintText: "xxxx"),
                                  keyboardType: TextInputType.text,
                                  obscureText: true,
                                  controller: passwordController,
                                  validator: (value) {
                                    if (value!.isEmpty || value.length <= 5) {
                                      return 'invalid password';
                                    }
                                    return null;
                                  },
                                ),
                                TextFormField(
                                  controller: confirm,
                                  style: TextStyle(color: Colors.white),
                                  decoration: InputDecoration(
                                      labelText: "Confirm Password",
                                      hintText: "xxxx"),
                                  keyboardType: TextInputType.text,
                                  obscureText: true,
                                  validator: (value) {
                                    if (value!.isEmpty ||
                                        value != passwordController.text) {
                                      return 'invalid password';
                                    }
                                    return null;
                                  },
                                  onSaved: (value) {},
                                ),
                                new MaterialButton(
                                  color: Colors.teal,
                                  textColor: Colors.white,
                                  child: new Text("Login"),
                                  onPressed: () => {
                                    if (passwordController.text ==
                                            confirm.text &&
                                        confirm.text.isNotEmpty)
                                      {
                                        createUser(
                                            nameController.text,
                                            emailController.text,
                                            passwordController.text),
                                        print("user created")
                                      }
                                  },
                                  splashColor: Colors.blueAccent,
                                ),
                                new MaterialButton(
                                  color: Colors.teal,
                                  textColor: Colors.white,
                                  child: new Text("cancel"),
                                  onPressed: () => {
                                    Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) => LoginPage()))
                                  },
                                  splashColor: Colors.blueAccent,
                                ),
                              ]),
                        ))),
              ]),
        ]));
  }
}
