class MeetingUser{
  int id;
  String name;

  MeetingUser(this.id, this.name);


}