import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:the_final_app_caucus/attendance.dart';

// ignore: must_be_immutable

class AttendanceScreen extends StatefulWidget {
  List<Attendance> students = [];

  String meetingID;

  AttendanceScreen(this.students, this.meetingID);

  @override
  _AttendanceScreenState createState() => _AttendanceScreenState();
}

class _AttendanceScreenState extends State<AttendanceScreen> {
  bool isLoading = true;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    DateTime now = DateTime.now();
    for (Attendance obj in widget.students) {
      if (obj.endTime.isEmpty) {
        var time = '${now.hour}:${now.minute}:${now.second}';
        obj.endTime = time;
        print(obj.endTime);
      }
    }

    this._uploadData();
  }

  _uploadData() async {
    isLoading = false;

    CollectionReference attendance =
        FirebaseFirestore.instance.collection('attendance');
    attendance
        .doc(widget.meetingID.toString())
        .set({'date': DateTime.now().toIso8601String()});
    CollectionReference users =
        attendance.doc(widget.meetingID.toString()).collection('users');
    for (Attendance obj in widget.students) {
      users.add({
        'join': obj.startTime,
        'left': obj.endTime,
        'name': obj.name,
        'uId': obj.uId
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          title: Text('Attendance'),
        ),
        body: isLoading
            ? Center(
                child: Text(
                  'Getting Data',
                  style: TextStyle(color: Colors.red, fontSize: 20.0),
                ),
              )
            : ListView.builder(
                itemCount: widget.students.length,
                itemBuilder: (context, position) {
                  Attendance attendance = widget.students[position];
                  return AttendanceTile(attendance.name, attendance.startTime,
                      attendance.endTime);
                },
              ),
      ),
    );
  }
}

class AttendanceTile extends StatelessWidget {
  String name;
  String startDate;
  String endDate;

  AttendanceTile(this.name, this.startDate, this.endDate);

  @override
  Widget build(BuildContext context) {
    return ListTile(
      title: Text('$name'),
      subtitle: Text('Join:$startDate \tEnd:$endDate'),
    );
  }
}
