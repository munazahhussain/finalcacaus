class Attendance{
  int uId;
  String name;
  String startTime;
  String endTime;

  Attendance(this.uId, this.name, this.startTime, this.endTime);
}