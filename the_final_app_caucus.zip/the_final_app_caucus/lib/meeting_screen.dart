import 'package:agora_uikit/agora_uikit.dart';
import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import 'package:the_final_app_caucus/attendance.dart';
import 'package:the_final_app_caucus/attendance_screen.dart';
import 'package:the_final_app_caucus/participants_screen.dart';
import 'package:the_final_app_caucus/user.dart';
import 'package:the_final_app_caucus/utils.dart';

import 'dashboard.dart';

// ignore: must_be_immutable
class MeetingScreen extends StatefulWidget {
  String token;
  String channelId;
  String link;
  String meetingId;
  bool isJoin;
  MeetingUser user;

  MeetingScreen(this.token, this.channelId, this.link, this.meetingId,
      this.isJoin, this.user);

  @override
  _MeetingScreenState createState() => _MeetingScreenState();
}

class _MeetingScreenState extends State<MeetingScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _iconAnimationController;
  late Animation<double> _iconAnimation;
  List<Attendance> students = [];
  List<MeetingUser> activeUsers = [];

  bool isJoined = false, switchCamera = true, switchRender = true;
  bool isMute = false;
  bool isHeadphone = false;

  bool isVideoOn = true;

  @override
  void dispose() {
    super.dispose();
    client.sessionController.endCall();
  }

  late AgoraClient client;

  @override
  void initState() {
    super.initState();
    _iconAnimationController = new AnimationController(
        vsync: this, duration: new Duration(milliseconds: 500));
    _iconAnimation = new CurvedAnimation(
        parent: _iconAnimationController, curve: Curves.easeOut);
    _iconAnimation.addListener(() => this.setState(() {}));
    _iconAnimationController.forward();
    print('clima');
    print(widget.user.name);
    client = AgoraClient(
      agoraConnectionData: AgoraConnectionData(
        appId: APP_ID,
        channelName: widget.channelId,
        stringUid: widget.user.name.toString(),
        tempToken: widget.token,
        // tokenUrl: 'https://agoratokenbig.herokuapp.com'
      ),
      enabledPermission: [
        Permission.camera,
        Permission.microphone,
      ],
      agoraEventHandlers: AgoraEventHandlers(
        joinChannelSuccess: (channel, uid, elapsed) {
          // client.sessionController.userName(uid: 457).then((value) {
          //   print(value.toString());
          // });
          //idU = uid;
          print('clima 2');
          client.sessionController.userName(uid: uid).then((value) {
            print(value.toString());
            activeUsers.add(MeetingUser(uid, value.toString()));
          });
        },
        userJoined: (uid, elapsed) {
          print("USER JOINED: $uid");

          client.sessionController.userName(uid: uid).then((value) {
            print('clima 3');
            print(value.toString());
            Utils.showToast('${value.toString()} Joined');
            DateTime now = DateTime.now();
            var time = '${now.hour}:${now.minute}:${now.second}';
            //String formattedDate = DateFormat('yyyy-MM-dd – kk:mm').format(now);
            students.add(Attendance(uid, value.toString(), time, ""));
            activeUsers.add(MeetingUser(uid, value.toString()));
          });
        },
        userOffline: (uid, reason) {
          print("USER OFFLINE REASON $reason");
          DateTime now = DateTime.now();
          var time = '${now.hour}:${now.minute}:${now.second}';
          //String formattedDate = DateFormat('yyyy-MM-dd – kk:mm').format(now);
          for (Attendance obj in students) {
            if (obj.uId == uid) {
              obj.endTime = time;
              print(obj.endTime);
            }
          }

          for (MeetingUser obj in activeUsers) {
            if (obj.id == uid) {
              Utils.showToast('${obj.name.toString()} Left');
              activeUsers.remove(obj);
              print('removed');
              break;
            }
          }

          // client.sessionController.userName(uid: uid).then((value) {
          //
          // });
        },
        leaveChannel: (RtcStats stats) {},
        activeSpeaker: (int uid) {},
        localVideoStateChanged: (LocalVideoStreamState localVideoState,
            LocalVideoStreamError error) {},
        remoteAudioStateChanged: (int uid, AudioRemoteState state,
            AudioRemoteStateReason reason, int elapsed) {},
        remoteVideoStateChanged: (int uid, VideoRemoteState state,
            VideoRemoteStateReason reason, int elapsed) {},
        localAudioStateChanged:
            (AudioLocalState state, AudioLocalError error) {},
        tokenPrivilegeWillExpire: (String token) {},
        onError: (ErrorCode errorCode) {},
      ),
    );
  }

  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: Container(
          decoration: BoxDecoration(
            border: Border(
              bottom:
                  BorderSide(width: 0.5, color: Colors.grey.withOpacity(0.3)),
            ),
          ),
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  InkWell(
                    //onTap: _speaker(),
                    child: Icon(
                      isHeadphone ? Icons.headphones : Icons.volume_up,
                      color: Colors.white,
                    ),
                  ),
                  Row(children: [
                    Icon(
                      Icons.security_outlined,
                      color: Colors.green,
                      size: 15,
                    ),
                    Text(
                      "Caucus",
                      style: TextStyle(
                          fontSize: 17,
                          color: Colors.white70,
                          fontWeight: FontWeight.bold),
                    ),
                    Icon(
                      Icons.keyboard_arrow_down,
                      color: Colors.grey,
                      size: 20,
                    ),
                  ]),
                  GestureDetector(
                    onTap: () {
                      if (widget.isJoin) {
                        Navigator.pushAndRemoveUntil(
                            context,
                            MaterialPageRoute(builder: (_) => Dashboard()),
                            (route) => false);
                      } else {
                        try {
                          client.sessionController.endCall();
                        } catch (e) {}
                        if (students.isNotEmpty) {
                          Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => AttendanceScreen(
                                          students, widget.meetingId)))
                              .whenComplete(() {
                            //isLoading = false;
                            Navigator.pop(context);
                            //setState(() {});
                          });
                        } else if (students.isEmpty) {
                          Utils.showToast('No participant for attendance');
                          Navigator.pushAndRemoveUntil(
                              context,
                              MaterialPageRoute(builder: (_) => Dashboard()),
                              (route) => false);
                        }
                      }
                    },
                    child: Container(
                      decoration: BoxDecoration(
                          color: Colors.red,
                          borderRadius: BorderRadius.circular(8)),
                      child: Padding(
                        padding: const EdgeInsets.only(
                            left: 12, right: 12, top: 5, bottom: 5),
                        child: Text(
                          "Leave",
                          style: TextStyle(
                              fontSize: 15,
                              color: Colors.white,
                              fontWeight: FontWeight.w600),
                        ),
                      ),
                    ),
                  )
                ]),
          ),
        ),
      ),
      backgroundColor: Colors.black,
      body: SafeArea(
        child: Stack(
          children: [
            AgoraVideoViewer(
              client: client,
              layoutType: Layout.floating,
              //showNumberOfUsers: true,
              showAVState: true,
              //disabledVideoWidget: MuteWidget(),
            ),
          ],
        ),
      ),
      bottomNavigationBar: new BottomNavigationBar(
        items: [
          BottomNavigationBarItem(
            title: Text('Audio'),
            icon: InkWell(
              onTap: () {
                client.sessionController.toggleMute();
                isMute = !isMute;
                setState(() {});
              },
              child: Icon(!isMute ? Icons.mic_rounded : Icons.mic_off,
                  color: Colors.black),
            ),
          ),
          BottomNavigationBarItem(
            title: Text('Video'),
            icon: GestureDetector(
                onTap: () {
                  client.sessionController.switchCamera();
                },
                child: Icon(Icons.cameraswitch, color: Colors.black)),
          ),
          BottomNavigationBarItem(
            title: Text('Turn On/Off Camera'),
            icon: GestureDetector(
              onTap: () {
                client.sessionController.toggleCamera();
                isVideoOn = !isVideoOn;
                setState(() {});
              },
              child: Icon(isVideoOn ? Icons.videocam : Icons.videocam_off,
                  color: Colors.black),
            ),
          ),

          /*BottomNavigationBarItem(
            title: Text('Chat'),
            icon: Icon(Icons.chat, color: Colors.black),
          ),*/
          BottomNavigationBarItem(
            title: Text('Participants'),
            icon: GestureDetector(
              onTap: () {
                showGeneralDialog(
                  context: context,
                  pageBuilder: (context, animation, secondaryAnimation) =>
                      Scaffold(
                          backgroundColor: Colors.black87,
                          body: ParticipantsScreen(activeUsers, widget.user)),
                );
              },
              child: Icon(Icons.people, color: Colors.black),
            ),
          ),
          BottomNavigationBarItem(
            title: Text('Share'),
            icon: GestureDetector(
                onTap: () {
                  Share.share(
                      'Join meeting on Caucus \nMeeting ID: ${widget.meetingId}\n ${widget.link}');
                },
                child: Icon(Icons.share, color: Colors.black)),
          ),
        ],
      ),
      floatingActionButton: Visibility(
        visible: false,
        child: FloatingActionButton(
          onPressed: () {
            _settingModalBottomSheet(context);
          },
        ),
      ),
    );
  }

  void _settingModalBottomSheet(context) {
    showModalBottomSheet(
        context: context,
        builder: (BuildContext bc) {
          return Container(
            child: new Wrap(
              children: <Widget>[
                new ListTile(
                    trailing: new Icon(Icons.security),
                    title: new Text('Security'),
                    onTap: () => {}),
                new ListTile(
                  trailing: new Icon(Icons.chat),
                  title: new Text('Chat'),
                  onTap: () => {},
                ),
                new ListTile(
                  trailing: new Icon(Icons.settings),
                  title: new Text('Meeting Setting'),
                  onTap: () => {},
                ),
                new ListTile(
                  trailing: new Icon(Icons.videocam),
                  title: new Text("Youtube Video"),
                  onTap: () => {},
                ),
              ],
            ),
          );
        });
  }
}
