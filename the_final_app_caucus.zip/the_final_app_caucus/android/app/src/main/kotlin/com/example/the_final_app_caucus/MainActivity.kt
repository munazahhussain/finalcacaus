package com.example.the_final_app_caucus

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
